import logo from './logo.svg';
import './App.css';
import HelloWorldFile from './HelloWorldFile';
function App() {
  return (
    <>
      <HelloWorldFile/>
      {/*  also write a different way
      <HelloWorldFile></HelloWorldFile> */}
    </>
  );
}

export default App;
