import React from 'react'

export default function HelloWorldFile() {
  return (
    <div>
      <h1>Hello World</h1>
    </div>
  )
}
